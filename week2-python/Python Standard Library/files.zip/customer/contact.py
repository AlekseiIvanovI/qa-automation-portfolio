def contact_customer():
    print("Customer contact")
    pass
