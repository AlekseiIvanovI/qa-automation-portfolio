print("Customer initialized")
