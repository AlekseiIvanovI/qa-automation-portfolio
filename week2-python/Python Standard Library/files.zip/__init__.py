print("Ecommerce initialized")
