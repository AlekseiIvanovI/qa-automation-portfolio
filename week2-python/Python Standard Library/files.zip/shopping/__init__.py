print("Shopping initialized")
